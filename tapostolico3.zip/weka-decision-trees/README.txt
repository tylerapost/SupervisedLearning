Tyler Apostolico 

Weka Implementations of Various Machine Learning Algorithms

To run each algorithm

1. clone the repo
2. 

mvn:exec@<id>

1. knn      || id = knn
2. nn       || id = nn    || Neural Network
3. tree     || id = tree
4. svm      || id = svm
5. boosting || id = boost

Data files and code (all 5 algorithms) can be found in src/main/java/com/tylerapo